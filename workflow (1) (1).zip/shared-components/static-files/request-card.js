(function ($) {

    "use strict";


    /* ============================================================
       CONFIGURATION
       ============================================================ */

    const PROCESS_NAME =
        "GET_WORKFLOW_TIMELINE";


    /* ============================================================
       STATUS TRANSLATIONS
       ============================================================ */

    const STATUS_TRANSLATIONS = {

        COMPLETED:
            "مكتمل",

        WAITING:
            "بانتظار الإجراء",

        RUNNING:
            "قيد التنفيذ",

        TERMINATED:
            "تم إنهاؤه",

        FAULTED:
            "حدث خطأ",

        ASSIGNED:
            "تم الإسناد",

        UNASSIGNED:
            "غير مسند",

        INFO_REQUESTED:
            "مطلوب معلومات",

        PENDING:
            "قيد الانتظار"

    };


    /* ============================================================
       STATUS TEXT
       ============================================================ */

    function getStatusText(
        state,
        fallback
    ) {

        if (!state) {

            return (
                fallback ||
                "غير محدد"
            );

        }


        const normalized =
            String(state)
                .toUpperCase()
                .trim();


        return (
            STATUS_TRANSLATIONS[normalized] ||
            fallback ||
            state
        );

    }


    /* ============================================================
       ESCAPE HTML
       ============================================================ */

    function escapeHtml(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }


        return String(value)

            .replace(
                /&/g,
                "&amp;"
            )

            .replace(
                /</g,
                "&lt;"
            )

            .replace(
                />/g,
                "&gt;"
            )

            .replace(
                /"/g,
                "&quot;"
            )

            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* ============================================================
       DATE PARSER
       ============================================================ */

    function parseOracleDate(value) {

        if (!value) {

            return null;

        }


        let text =
            String(value).trim();


        /*
         * Oracle ISO-like:
         *
         * 2026-08-29T14:30:00
         *
         * Treat it as local browser time.
         */

        const match =
            text.match(
                /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})$/
            );


        if (match) {

            const year =
                parseInt(
                    match[1],
                    10
                );

            const month =
                parseInt(
                    match[2],
                    10
                ) - 1;

            const day =
                parseInt(
                    match[3],
                    10
                );

            const hour =
                parseInt(
                    match[4],
                    10
                );

            const minute =
                parseInt(
                    match[5],
                    10
                );

            const second =
                parseInt(
                    match[6],
                    10
                );


            return new Date(
                year,
                month,
                day,
                hour,
                minute,
                second
            );

        }


        const parsed =
            new Date(text);


        if (
            isNaN(
                parsed.getTime()
            )
        ) {

            return null;

        }


        return parsed;

    }


    /* ============================================================
       ARABIC NUMBER GRAMMAR
       ============================================================ */

    function arabicCount(
        number,
        one,
        two,
        few,
        many
    ) {

        if (number === 1) {

            return one;

        }


        if (number === 2) {

            return two;

        }


        if (
            number >= 3 &&
            number <= 10
        ) {

            return (
                number +
                " " +
                few
            );

        }


        return (
            number +
            " " +
            many
        );

    }


    /* ============================================================
       FACEBOOK STYLE RELATIVE TIME
       ============================================================ */

    function getRelativeTime(
        dateValue
    ) {

        const date =
            parseOracleDate(
                dateValue
            );


        if (!date) {

            return "";

        }


        const now =
            new Date();


        let seconds =
            Math.floor(
                (
                    now.getTime() -
                    date.getTime()
                ) / 1000
            );


        /*
         * Future dates protection
         */

        if (seconds < 0) {

            seconds = 0;

        }


        const MINUTE =
            60;

        const HOUR =
            MINUTE * 60;

        const DAY =
            HOUR * 24;

        const WEEK =
            DAY * 7;

        const MONTH =
            DAY * 30;

        const YEAR =
            DAY * 365;


        /* ========================================================
           SECONDS
           ======================================================== */

        if (
            seconds < MINUTE
        ) {

            return "لحظات";

        }


        /* ========================================================
           MINUTES
           ======================================================== */

        if (
            seconds < HOUR
        ) {

            const minutes =
                Math.floor(
                    seconds / MINUTE
                );


            return arabicCount(
                minutes,
                "دقيقة واحدة",
                "دقيقتين",
                "دقائق",
                "دقيقة"
            );

        }


        /* ========================================================
           HOURS
           ======================================================== */

        if (
            seconds < DAY
        ) {

            const hours =
                Math.floor(
                    seconds / HOUR
                );


            return arabicCount(
                hours,
                "ساعة واحدة",
                "ساعتين",
                "ساعات",
                "ساعة"
            );

        }


        /* ========================================================
           DAYS
           ======================================================== */

        if (
            seconds < WEEK
        ) {

            const days =
                Math.floor(
                    seconds / DAY
                );


            return arabicCount(
                days,
                "يوم واحد",
                "يومين",
                "أيام",
                "يوم"
            );

        }


        /* ========================================================
           WEEKS
           ======================================================== */

        if (
            seconds < MONTH
        ) {

            const weeks =
                Math.floor(
                    seconds / WEEK
                );


            return arabicCount(
                weeks,
                "أسبوع واحد",
                "أسبوعين",
                "أسابيع",
                "أسبوع"
            );

        }


        /* ========================================================
           MONTHS
           ======================================================== */

        if (
            seconds < YEAR
        ) {

            const months =
                Math.floor(
                    seconds / MONTH
                );


            return arabicCount(
                months,
                "شهر واحد",
                "شهرين",
                "أشهر",
                "شهر"
            );

        }


        /* ========================================================
           YEARS
           ======================================================== */

        const years =
            Math.floor(
                seconds / YEAR
            );


        return arabicCount(
            years,
            "سنة واحدة",
            "سنتين",
            "سنوات",
            "سنة"
        );

    }


    /* ============================================================
       UPDATE RELATIVE TIMES
       ============================================================ */

    function updateRelativeTimes(
        root
    ) {

        const $root =
            root
                ? $(root)
                : $(document);


        $root
            .find(
                ".request-relative-time"
            )
            .each(
                function () {

                    const $time =
                        $(this);


                    const requestDate =
                        $time.attr(
                            "data-request-date"
                        );


                    const relative =
                        getRelativeTime(
                            requestDate
                        );


                    if (relative) {

                        $time.text(
                            relative
                        );

                    }

                }
            );

    }


    /* ============================================================
       ACTIVITY ICON
       ============================================================ */

    function getActivityIcon(
        activity
    ) {

        const state =
            String(
                activity.state || ""
            )
                .toUpperCase()
                .trim();


        switch (state) {

            case "COMPLETED":
                return "fa-check";

            case "FAULTED":
                return "fa-exclamation-triangle";

            case "TERMINATED":
                return "fa-times";

            case "WAITING":
                return "fa-clock-o";

            case "RUNNING":
                return "fa-spinner";

            case "ASSIGNED":
                return "fa-user";

            case "UNASSIGNED":
                return "fa-user-o";

            default:
                return "fa-circle-o";

        }

    }


    /* ============================================================
       TIMELINE CLASS
       ============================================================ */

    function getTimelineClass(
        activity,
        isCurrent
    ) {

        const state =
            String(
                activity.state || ""
            )
                .toUpperCase()
                .trim();


        let classes =
            "workflow-timeline-item";


        if (
            state === "COMPLETED"
        ) {

            classes +=
                " is-completed";

        }


        if (
            state === "WAITING" ||
            state === "RUNNING" ||
            state === "ASSIGNED" ||
            state === "UNASSIGNED"
        ) {

            classes +=
                " is-warning";

        }


        if (
            state === "FAULTED" ||
            state === "TERMINATED"
        ) {

            classes +=
                " is-danger";

        }


        if (isCurrent) {

            classes +=
                " is-current";

        }


        return classes;

    }


    /* ============================================================
       LOAD WORKFLOW
       ============================================================ */

    function loadWorkflow(
        $card,
        forceReload
    ) {

        const requestId =
            String(
                $card.attr(
                    "data-request-id"
                ) || ""
            ).trim();


        if (
            !requestId ||
            !/^\d+$/.test(
                requestId
            )
        ) {

            console.error(
                "Workflow: Invalid request ID",
                requestId
            );

            showWorkflowError(
                $card.find(
                    ".request-workflow-panel"
                ),
                "رقم الطلب غير صالح"
            );

            return;

        }


        const $panel =
            $card.find(
                ".request-workflow-panel"
            );


        if (!$panel.length) {

            return;

        }


        const $timeline =
            $panel.find(
                ".workflow-timeline-items"
            );


        const $empty =
            $panel.find(
                ".workflow-empty"
            );


        const $error =
            $panel.find(
                ".workflow-error"
            );


        const $currentStatus =
            $panel.find(
                ".workflow-current-status-value"
            );


        /*
         * Already loaded
         */

        if (
            !forceReload &&
            $card.attr(
                "data-workflow-loaded"
            ) === "true"
        ) {

            return;

        }


        /*
         * Reset
         */

        $error.removeClass(
            "is-visible"
        );

        $empty.removeClass(
            "is-visible"
        );

        $timeline.empty();


        $currentStatus.text(
            "جاري تحميل سير العمل..."
        );


        $panel.addClass(
            "is-loading"
        );


        /*
         * AJAX
         */

        apex.server.process(

            PROCESS_NAME,

            {

                x01:
                    requestId

            },

            {

                dataType:
                    "json",


                success:
                    function (response) {

                        console.log(
                            "Workflow Response:",
                            response
                        );


                        $panel.removeClass(
                            "is-loading"
                        );


                        if (
                            !response ||
                            response.success !== true
                        ) {

                            showWorkflowError(

                                $panel,

                                response &&
                                response.message
                                    ? response.message
                                    : "تعذر تحميل سير العمل",

                                response

                            );

                            return;

                        }


                        /*
                         * Current status
                         */

                        renderCurrentStatus(

                            $panel,

                            response.current_task

                        );


                        /*
                         * Timeline
                         */

                        const timeline =
                            Array.isArray(
                                response.timeline
                            )
                                ? response.timeline
                                : [];


                        if (
                            timeline.length === 0
                        ) {

                            $empty.addClass(
                                "is-visible"
                            );

                        } else {

                            renderTimeline(

                                $panel,

                                timeline,

                                response.current_task

                            );

                        }


                        /*
                         * Mark loaded
                         */

                        $card.attr(
                            "data-workflow-loaded",
                            "true"
                        );

                    },


                error:
                    function (
                        jqXHR,
                        textStatus,
                        errorThrown
                    ) {

                        $panel.removeClass(
                            "is-loading"
                        );


                        console.error(
                            "Workflow AJAX Error:",
                            textStatus,
                            errorThrown
                        );


                        console.error(
                            "HTTP Status:",
                            jqXHR.status
                        );


                        console.error(
                            "RAW Response:",
                            jqXHR.responseText
                        );


                        let message =
                            "حدث خطأ أثناء الاتصال بالخادم";


                        const raw =
                            String(
                                jqXHR.responseText ||
                                ""
                            ).trim();


                        if (raw) {

                            try {

                                const parsed =
                                    JSON.parse(
                                        raw
                                    );


                                if (
                                    parsed &&
                                    parsed.message
                                ) {

                                    message =
                                        parsed.message;

                                }

                            } catch (e) {

                                console.warn(
                                    "Response is not JSON",
                                    e
                                );

                            }

                        }


                        showWorkflowError(

                            $panel,

                            message,

                            {

                                status:
                                    jqXHR.status,

                                textStatus:
                                    textStatus,

                                errorThrown:
                                    errorThrown,

                                rawResponse:
                                    raw

                            }

                        );

                    }

            }

        );

    }


    /* ============================================================
       CURRENT STATUS
       ============================================================ */

    function renderCurrentStatus(
        $panel,
        currentTask
    ) {

        const $value =
            $panel.find(
                ".workflow-current-status-value"
            );


        if (!$value.length) {

            return;

        }


        if (
            !currentTask ||
            currentTask.exists !== true
        ) {

            $value.text(
                "لا توجد مهمة حالية"
            );


            setCurrentStatusIcon(
                $panel,
                "INFO"
            );


            return;

        }


        const state =
            currentTask.state_code ||
            currentTask.state ||
            "";


        const text =
            getStatusText(
                state,
                currentTask.state
            );


        $value.text(
            text
        );


        setCurrentStatusIcon(
            $panel,
            state
        );

    }


    /* ============================================================
       CURRENT STATUS ICON
       ============================================================ */

    function setCurrentStatusIcon(
        $panel,
        state
    ) {

        const $icon =
            $panel.find(
                ".workflow-current-status-icon"
            );


        $icon.removeClass(
            "is-info is-warning is-danger is-success"
        );


        const normalized =
            String(state || "")
                .toUpperCase()
                .trim();


        if (
            normalized === "COMPLETED"
        ) {

            $icon.addClass(
                "is-success"
            );

        } else if (
            normalized === "FAULTED" ||
            normalized === "TERMINATED"
        ) {

            $icon.addClass(
                "is-danger"
            );

        } else if (
            normalized === "WAITING" ||
            normalized === "INFO_REQUESTED" ||
            normalized === "ASSIGNED" ||
            normalized === "UNASSIGNED"
        ) {

            $icon.addClass(
                "is-warning"
            );

        } else {

            $icon.addClass(
                "is-info"
            );

        }

    }


    /* ============================================================
       RENDER TIMELINE
       ============================================================ */

    function renderTimeline(
        $panel,
        timeline,
        currentTask
    ) {

        const $container =
            $panel.find(
                ".workflow-timeline-items"
            );


        if (!$container.length) {

            return;

        }


        $container.empty();


        let currentActivityId =
            null;


        if (
            currentTask &&
            currentTask.exists === true &&
            currentTask.workflow_activity_id !== null &&
            currentTask.workflow_activity_id !== undefined
        ) {

            currentActivityId =
                String(
                    currentTask.workflow_activity_id
                );

        }


        let currentFound =
            false;


        timeline.forEach(
            function (activity) {

                const activityId =
                    activity.activity_id !== null &&
                    activity.activity_id !== undefined
                        ? String(
                            activity.activity_id
                        )
                        : "";


                let isCurrent =
                    false;


                if (
                    currentActivityId &&
                    activityId ===
                    currentActivityId
                ) {

                    isCurrent =
                        true;

                    currentFound =
                        true;

                }


                $container.append(

                    buildTimelineItem(
                        activity,
                        isCurrent
                    )

                );

            }
        );


        /*
         * Fallback current item
         */

        if (
            currentTask &&
            currentTask.exists === true &&
            !currentFound
        ) {

            const state =
                String(
                    currentTask.state_code ||
                    currentTask.state ||
                    ""
                )
                    .toUpperCase()
                    .trim();


            if (
                state === "INFO_REQUESTED" ||
                state === "WAITING" ||
                state === "ASSIGNED" ||
                state === "UNASSIGNED"
            ) {

                const $fallback =
                    $container
                        .find(
                            ".workflow-timeline-item"
                        )
                        .filter(
                            function () {

                                const itemState =
                                    String(
                                        $(this).attr(
                                            "data-state"
                                        ) || ""
                                    )
                                        .toUpperCase()
                                        .trim();


                                return (
                                    itemState === "WAITING" ||
                                    itemState === "ASSIGNED" ||
                                    itemState === "UNASSIGNED"
                                );

                            }
                        )
                        .first();


                if (
                    $fallback.length
                ) {

                    $fallback.addClass(
                        "is-current"
                    );


                    if (
                        !$fallback.find(
                            ".workflow-current-label"
                        ).length
                    ) {

                        $fallback
                            .find(
                                ".workflow-timeline-content"
                            )
                            .append(

                                '<span class="workflow-current-label">' +

                                    '<span class="fa fa-dot-circle-o"></span>' +

                                    ' الحالة الحالية' +

                                '</span>'

                            );

                    }

                }

            }

        }

    }


    /* ============================================================
       BUILD TIMELINE ITEM
       ============================================================ */

    function buildTimelineItem(
        activity,
        isCurrent
    ) {

        const state =
            String(
                activity.state || ""
            )
                .toUpperCase()
                .trim();


        const itemClass =
            getTimelineClass(
                activity,
                isCurrent
            );


        const icon =
            getActivityIcon(
                activity
            );


        const stateText =
            getStatusText(
                state,
                activity.badge_text
            );


        const badgeState =
            String(
                activity.badge_state ||
                "info"
            )
                .toLowerCase();


        const name =
            escapeHtml(
                activity.name ||
                "مرحلة سير العمل"
            );


        const type =
            escapeHtml(
                activity.type ||
                ""
            );


        const startTime =
            escapeHtml(
                activity.start_time ||
                ""
            );


        const endTime =
            escapeHtml(
                activity.end_time ||
                ""
            );


        const dueOn =
            escapeHtml(
                activity.due_on ||
                ""
            );


        const retryCount =
            activity.retry_count !== null &&
            activity.retry_count !== undefined
                ? activity.retry_count
                : 0;


        const errorMessage =
            escapeHtml(
                activity.error_message ||
                ""
            );


        let dateText =
            startTime;


        if (
            endTime &&
            endTime !== startTime
        ) {

            dateText =
                startTime +
                " → " +
                endTime;

        }


        let html = "";


        html +=
            '<div class="' +
            itemClass +
            '"' +

            ' data-state="' +
            escapeHtml(
                state
            ) +
            '"' +

            ' data-activity-id="' +
            escapeHtml(
                activity.activity_id ||
                ""
            ) +
            '">';


        /*
         * Marker
         */

        html +=

            '<div class="workflow-timeline-marker">' +

                '<span class="fa ' +
                    icon +
                '"></span>' +

            '</div>';


        /*
         * Content
         */

        html +=
            '<div class="workflow-timeline-content">';


        html +=
            '<div class="workflow-timeline-top">';


        html +=
            '<div class="workflow-timeline-heading">';


        html +=
            '<div class="workflow-timeline-name">' +
                name +
            '</div>';


        if (type) {

            html +=
                '<div class="workflow-timeline-type">' +
                    type +
                '</div>';

        }


        html +=
            '</div>';


        if (dateText) {

            html +=
                '<div class="workflow-timeline-date">' +
                    dateText +
                '</div>';

        }


        html +=
            '</div>';


        /*
         * Badge
         */

        html +=

            '<span class="workflow-timeline-badge ' +
                escapeHtml(
                    badgeState
                ) +
            '">' +

                escapeHtml(
                    stateText
                ) +

            '</span>';


        /*
         * Current
         */

        if (isCurrent) {

            html +=

                '<span class="workflow-current-label">' +

                    '<span class="fa fa-dot-circle-o"></span>' +

                    ' الحالة الحالية' +

                '</span>';

        }


        /*
         * Due
         */

        if (dueOn) {

            html +=

                '<div class="workflow-timeline-meta">' +

                    '<span class="fa fa-calendar"></span>' +

                    ' الاستحقاق: ' +

                    dueOn +

                '</div>';

        }


        /*
         * Retry
         */

        if (retryCount > 0) {

            html +=

                '<div class="workflow-timeline-meta">' +

                    '<span class="fa fa-refresh"></span>' +

                    ' محاولات الإعادة: ' +

                    escapeHtml(
                        retryCount
                    ) +

                '</div>';

        }


        /*
         * Error
         */

        if (errorMessage) {

            html +=

                '<div class="workflow-timeline-error">' +

                    '<span class="fa fa-exclamation-triangle"></span> ' +

                    errorMessage +

                '</div>';

        }


        html +=
            '</div>';


        html +=
            '</div>';


        return html;

    }


    /* ============================================================
       ERROR
       ============================================================ */

    function showWorkflowError(
        $panel,
        message,
        details
    ) {

        const $error =
            $panel.find(
                ".workflow-error"
            );


        const $message =
            $error.find(
                ".workflow-error-message"
            );


        $message.text(
            message ||
            "تعذر تحميل سير العمل"
        );


        $error.addClass(
            "is-visible"
        );


        if (details) {

            console.error(
                "Workflow Details:",
                details
            );

        }

    }


    /* ============================================================
       CARD CLICK
       ============================================================ */

    $(document).on(
        "click",
        ".request-card",
        function (event) {

            /*
             * Retry button
             */

            if (
                $(event.target).closest(
                    ".workflow-retry-btn"
                ).length
            ) {

                return;

            }


            /*
             * Prevent click when selecting text
             */

            if (
                window.getSelection &&
                window.getSelection().toString()
            ) {

                return;

            }


            const $card =
                $(this);


            const expanded =
                $card.hasClass(
                    "is-expanded"
                );


            if (expanded) {

                $card.removeClass(
                    "is-expanded"
                );


                $card.attr(
                    "aria-expanded",
                    "false"
                );


                $card.find(
                    ".request-workflow-panel"
                ).attr(
                    "aria-hidden",
                    "true"
                );


                return;

            }


            /*
             * Expand
             */

            $card.addClass(
                "is-expanded"
            );


            $card.attr(
                "aria-expanded",
                "true"
            );


            $card.find(
                ".request-workflow-panel"
            ).attr(
                "aria-hidden",
                "false"
            );


            /*
             * Load workflow
             */

            loadWorkflow(
                $card,
                false
            );

        }
    );


    /* ============================================================
       KEYBOARD ACCESS
       ============================================================ */

    $(document).on(
        "keydown",
        ".request-card",
        function (event) {

            if (
                event.key !== "Enter" &&
                event.key !== " "
            ) {

                return;

            }


            /*
             * Do not activate retry
             */

            if (
                $(event.target).closest(
                    ".workflow-retry-btn"
                ).length
            ) {

                return;

            }


            event.preventDefault();


            $(this).trigger(
                "click"
            );

        }
    );


    /* ============================================================
       RETRY
       ============================================================ */

    $(document).on(
        "click",
        ".workflow-retry-btn",
        function (event) {

            event.preventDefault();

            event.stopPropagation();


            const $card =
                $(this).closest(
                    ".request-card"
                );


            if (!$card.length) {

                return;

            }


            $card.attr(
                "data-workflow-loaded",
                "false"
            );


            loadWorkflow(
                $card,
                true
            );

        }
    );


    /* ============================================================
       UPDATE RELATIVE TIME EVERY MINUTE
       ============================================================ */

    function startRelativeTimeUpdater() {

        updateRelativeTimes();


        setInterval(
            function () {

                updateRelativeTimes();

            },
            60000
        );

    }


    /* ============================================================
       APEX AFTER REFRESH
       ============================================================ */

    $(document).on(
        "apexafterrefresh",
        function () {

            updateRelativeTimes();

        }
    );


    /* ============================================================
       INITIALIZATION
       ============================================================ */

    $(function () {

        console.log(
            "Request Workflow Timeline initialized"
        );


        console.log(
            "Ajax Callback:",
            PROCESS_NAME
        );


        startRelativeTimeUpdater();

    });


})(apex.jQuery);