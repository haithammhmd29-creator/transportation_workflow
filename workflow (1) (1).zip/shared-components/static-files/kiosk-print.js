console.log("================================");
console.log("KIOSK-PRINT.JS LOADED");
console.log("================================");


/*
 * ============================================================
 * KIOSK RECEIPT CONFIGURATION
 * ============================================================
 *
 * Designed for:
 * 80mm Thermal Printer
 *
 * Typical width:
 * 48 characters
 *
 * For 58mm:
 * change WIDTH to 32
 *
 * ============================================================
 */


const RECEIPT_CONFIG = {

    PAPER: "80mm",

    WIDTH: 48,

    PRINTER: "KIOSK_VIRTUAL_RECEIPT",

    COPIES: 1,

    CUT_PAPER: true,

    HEADER: {
        FONT_SIZE: "DOUBLE",
        BOLD: true,
        ALIGN: "CENTER"
    },

    BODY: {
        FONT_SIZE: "NORMAL",
        BOLD: false,
        ALIGN: "LEFT"
    },

    TOTAL: {
        FONT_SIZE: "DOUBLE",
        BOLD: true,
        ALIGN: "CENTER"
    },

    FOOTER: {
        ALIGN: "CENTER",
        BOLD: false
    }

};


/*
 * ============================================================
 * ESC/POS COMMANDS
 * ============================================================
 */


const ESC = "\x1B";
const GS  = "\x1D";
const LF  = "\x0A";


const ESC_POS = {

    INIT:
        ESC + "@",

    ALIGN_LEFT:
        ESC + "a" + "\x00",

    ALIGN_CENTER:
        ESC + "a" + "\x01",

    ALIGN_RIGHT:
        ESC + "a" + "\x02",

    BOLD_ON:
        ESC + "E" + "\x01",

    BOLD_OFF:
        ESC + "E" + "\x00",

    NORMAL_SIZE:
        GS + "!" + "\x00",

    DOUBLE_SIZE:
        GS + "!" + "\x11",

    UNDERLINE_ON:
        ESC + "-" + "\x01",

    UNDERLINE_OFF:
        ESC + "-" + "\x00",

    CUT:
        GS + "V" + "\x00"

};


/*
 * ============================================================
 * HELPER FUNCTIONS
 * ============================================================
 */


function line() {

    return (
        "-".repeat(RECEIPT_CONFIG.WIDTH) +
        LF
    );

}


function doubleLine() {

    return (
        "=".repeat(RECEIPT_CONFIG.WIDTH) +
        LF
    );

}


function center(text) {

    if (!text) {
        return LF;
    }

    return (
        ESC_POS.ALIGN_CENTER +
        text +
        LF
    );

}


function left(text) {

    if (!text) {
        return LF;
    }

    return (
        ESC_POS.ALIGN_LEFT +
        text +
        LF
    );

}


/*
 * Create:
 *
 * LABEL                  VALUE
 *
 */


function twoColumn(label, value) {

    label = String(label || "");
    value = String(value || "");

    const width =
        RECEIPT_CONFIG.WIDTH;

    /*
     * If the value is too long,
     * truncate it.
     */

    if (value.length > width) {

        value =
            value.substring(
                0,
                width
            );

    }


    const available =
        width -
        value.length;


    if (label.length >= available) {

        label =
            label.substring(
                0,
                available - 1
            );

    }


    const spaces =
        " ".repeat(
            Math.max(
                1,
                available - label.length
            )
        );


    return (
        label +
        spaces +
        value +
        LF
    );

}


/*
 * ============================================================
 * PRINT RECEIPT
 * ============================================================
 */


async function printReceipt() {

    try {

        console.log(
            "================================"
        );

        console.log(
            "PRINT RECEIPT START"
        );

        console.log(
            "================================"
        );


        /*
         * ====================================================
         * 1. CHECK QZ
         * ====================================================
         */

        if (typeof qz === "undefined") {

            throw new Error(
                "QZ Tray library is not loaded."
            );

        }


        console.log(
            "QZ object available."
        );


        /*
         * ====================================================
         * 2. CONNECT TO QZ TRAY
         * ====================================================
         */

        if (!qz.websocket.isActive()) {

            console.log(
                "Connecting to QZ Tray..."
            );

            await qz.websocket.connect();

        }


        console.log(
            "QZ Tray connected."
        );


        /*
         * ====================================================
         * 3. FIND PRINTER
         * ====================================================
         */

        const printerName =
            RECEIPT_CONFIG.PRINTER;


        console.log(
            "Looking for printer:",
            printerName
        );


        const printer =
            await qz.printers.find(
                printerName
            );


        console.log(
            "Printer found:",
            printer
        );


        /*
         * ====================================================
         * 4. CALL APEX AJAX
         * ====================================================
         */

        console.log(
            "Calling GET_RECEIPT..."
        );


        const result =
            await apex.server.process(
                "GET_RECEIPT",
                {},
                {
                    dataType: "json"
                }
            );


        console.log(
            "ORDS / APEX RESULT:",
            result
        );


        /*
         * ====================================================
         * 5. VALIDATE API
         * ====================================================
         */

        if (!result.success) {

            throw new Error(
                result.message ||
                result.error ||
                "Receipt API failed."
            );

        }


        if (!result.receipt) {

            throw new Error(
                "Receipt data not found."
            );

        }


        const receipt =
            result.receipt;


        console.log(
            "Receipt received:",
            receipt
        );


        /*
         * ====================================================
         * 6. EXTRACT DATA
         * ====================================================
         */


        const receiptNo =
            receipt.receipt_no || "-";


        const transactionId =
            receipt.transaction_id || "-";


        const orderNumber =
            receipt.order_number || "-";


        const date =
            receipt.date || "-";


        const time =
            receipt.time || "-";


        const terminal =
            receipt.terminal || "-";


        const status =
            receipt.status || {};


        const transaction =
            receipt.transaction || {};


        const amounts =
            receipt.amounts || {};


        const payment =
            receipt.payment || {};


        const footer =
            receipt.footer || {};


        /*
         * ====================================================
         * 7. FORMAT AMOUNTS
         * ====================================================
         */


        const amount =
            Number(
                amounts.amount || 0
            ).toFixed(2);


        const discount =
            Number(
                amounts.discount || 0
            ).toFixed(2);


        const tax =
            Number(
                amounts.tax || 0
            ).toFixed(2);


        const total =
            Number(
                amounts.total || 0
            ).toFixed(2);


        const paid =
            Number(
                amounts.paid || 0
            ).toFixed(2);


        /*
         * ====================================================
         * 8. BUILD RECEIPT
         * ====================================================
         */


        let data = "";


        /*
         * RESET PRINTER
         */

        data +=
            ESC_POS.INIT;


        /*
         * ====================================================
         * HEADER
         * ====================================================
         */


        data +=
            ESC_POS.ALIGN_CENTER;


        data +=
            ESC_POS.BOLD_ON;


        data +=
            ESC_POS.DOUBLE_SIZE;


        data +=
            "BANK NAME" +
            LF;


        data +=
            ESC_POS.NORMAL_SIZE;


        data +=
            "SELF SERVICE KIOSK" +
            LF;


        data +=
            ESC_POS.BOLD_OFF;


        data += LF;


        /*
         * Optional branch / location
         */

        data +=
            "Customer Service Center" +
            LF;


        data +=
            doubleLine();


        /*
         * ====================================================
         * SUCCESS STATUS
         * ====================================================
         */


        data +=
            ESC_POS.BOLD_ON;


        data +=
            ESC_POS.DOUBLE_SIZE;


        data +=
            (
                status.message ||
                "TRANSACTION COMPLETED"
            ) +
            LF;


        data +=
            ESC_POS.NORMAL_SIZE;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            line();


        /*
         * ====================================================
         * RECEIPT INFORMATION
         * ====================================================
         */


        data +=
            ESC_POS.ALIGN_LEFT;


        data +=
            ESC_POS.BOLD_ON;


        data +=
            "RECEIPT INFORMATION" +
            LF;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            twoColumn(
                "Receipt No.",
                receiptNo
            );


        data +=
            twoColumn(
                "Transaction ID",
                transactionId
            );


        data +=
            twoColumn(
                "Order No.",
                orderNumber
            );


        data +=
            twoColumn(
                "Date",
                date
            );


        data +=
            twoColumn(
                "Time",
                time
            );


        data +=
            twoColumn(
                "Terminal",
                terminal
            );


        data +=
            line();


        /*
         * ====================================================
         * TRANSACTION
         * ====================================================
         */


        data +=
            ESC_POS.BOLD_ON;


        data +=
            "TRANSACTION" +
            LF;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            twoColumn(
                "Service",
                transaction.service || "-"
            );


        data +=
            twoColumn(
                "Description",
                transaction.description || "-"
            );


        data +=
            line();


        /*
         * ====================================================
         * PAYMENT
         * ====================================================
         */


        data +=
            ESC_POS.BOLD_ON;


        data +=
            "PAYMENT DETAILS" +
            LF;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            twoColumn(
                "Amount",
                amount
            );


        data +=
            twoColumn(
                "Discount",
                discount
            );


        data +=
            twoColumn(
                "Tax",
                tax
            );


        data +=
            twoColumn(
                "Payment Method",
                payment.method || "-"
            );


        data +=
            line();


        /*
         * ====================================================
         * TOTAL
         * ====================================================
         */


        data +=
            ESC_POS.ALIGN_CENTER;


        data +=
            ESC_POS.BOLD_ON;


        data +=
            "TOTAL" +
            LF;


        data +=
            ESC_POS.DOUBLE_SIZE;


        data +=
            total +
            LF;


        data +=
            ESC_POS.NORMAL_SIZE;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            line();


        /*
         * ====================================================
         * PAID
         * ====================================================
         */


        data +=
            ESC_POS.ALIGN_LEFT;


        data +=
            twoColumn(
                "Paid",
                paid
            );


        data +=
            doubleLine();


        /*
         * ====================================================
         * FOOTER
         * ====================================================
         */


        data +=
            ESC_POS.ALIGN_CENTER;


        data +=
            ESC_POS.BOLD_ON;


        data +=
            "THANK YOU" +
            LF;


        data +=
            ESC_POS.BOLD_OFF;


        data +=
            (
                footer.message ||
                "Thank you for using our self-service kiosk."
            ) +
            LF;


        data += LF;


        data +=
            "Please keep this receipt" +
            LF;


        data += LF;


        /*
         * ====================================================
         * PRINT DATE
         * ====================================================
         */


        data +=
            date +
            " " +
            time +
            LF;


        data += LF;


        data += LF;


        /*
         * ====================================================
         * CUT PAPER
         * ====================================================
         */


        if (
            RECEIPT_CONFIG.CUT_PAPER
        ) {

            data +=
                ESC_POS.CUT;

        }


        console.log(
            "================================"
        );

        console.log(
            "RAW RECEIPT CREATED"
        );

        console.log(
            "Paper:",
            RECEIPT_CONFIG.PAPER
        );

        console.log(
            "Width:",
            RECEIPT_CONFIG.WIDTH,
            "characters"
        );

        console.log(
            "RAW Length:",
            data.length
        );

        console.log(
            "================================"
        );


        /*
         * ====================================================
         * 9. QZ CONFIG
         * ====================================================
         */


        const config =
            qz.configs.create(
                printer
            );


        console.log(
            "QZ configuration created."
        );


        /*
         * ====================================================
         * 10. PRINT
         * ====================================================
         */


        console.log(
            "Sending receipt to QZ Tray..."
        );


        await qz.print(
            config,
            [
                {
                    type: "raw",
                    format: "plain",
                    data: data
                }
            ]
        );


        /*
         * ====================================================
         * 11. SUCCESS
         * ====================================================
         */


        console.log(
            "================================"
        );

        console.log(
            "PRINT SUCCESS"
        );

        console.log(
            "Printer:",
            printer
        );

        console.log(
            "Receipt:",
            receiptNo
        );

        console.log(
            "================================"
        );


        apex.message.showPageSuccess(
            "Receipt printed successfully."
        );


    }
    catch (error) {


        console.error(
            "================================"
        );

        console.error(
            "PRINT ERROR"
        );

        console.error(
            error
        );

        console.error(
            "================================"
        );


        apex.message.alert(
            "PRINT ERROR:\n\n" +
            (
                error.message ||
                JSON.stringify(error)
            )
        );

    }

}