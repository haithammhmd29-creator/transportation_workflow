(function () {

    "use strict";

    const REQUEST_SELECTOR = ".tr-request";

    const TOGGLE_SELECTOR =
        "[data-request-toggle], [data-request-button]";


    function expandRequest(request) {

        if (!request) {
            return;
        }

        request.classList.add("is-expanded");

        const header =
            request.querySelector("[data-request-toggle]");

        const details =
            request.querySelector(".tr-request__details");

        if (header) {

            header.setAttribute(
                "aria-expanded",
                "true"
            );

        }

        if (details) {

            details.setAttribute(
                "aria-hidden",
                "false"
            );

        }

    }


    function collapseRequest(request) {

        if (!request) {
            return;
        }

        request.classList.remove("is-expanded");

        const header =
            request.querySelector("[data-request-toggle]");

        const details =
            request.querySelector(".tr-request__details");

        if (header) {

            header.setAttribute(
                "aria-expanded",
                "false"
            );

        }

        if (details) {

            details.setAttribute(
                "aria-hidden",
                "true"
            );

        }

    }


    function toggleRequest(request) {

        if (
            request.classList.contains(
                "is-expanded"
            )
        ) {

            collapseRequest(request);

        } else {

            expandRequest(request);

        }

    }


    document.addEventListener(
        "click",
        function (event) {

            const trigger =
                event.target.closest(
                    TOGGLE_SELECTOR
                );

            if (!trigger) {
                return;
            }

            const request =
                trigger.closest(
                    REQUEST_SELECTOR
                );

            if (!request) {
                return;
            }

            /*
             * If the clicked element is the button,
             * prevent the button default.
             */

            if (
                trigger.matches(
                    "[data-request-button]"
                )
            ) {

                event.preventDefault();

            }

            toggleRequest(request);

        }
    );


    document.addEventListener(
        "keydown",
        function (event) {

            if (
                event.key !== "Enter" &&
                event.key !== " "
            ) {
                return;
            }

            const header =
                event.target.closest(
                    "[data-request-toggle]"
                );

            if (!header) {
                return;
            }

            event.preventDefault();

            const request =
                header.closest(
                    REQUEST_SELECTOR
                );

            toggleRequest(request);

        }
    );


})();